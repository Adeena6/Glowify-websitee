export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  oldPrice?: number;
  category: 'skincare' | 'makeup' | 'lip-care' | 'face-care';
  image: string;
  rating: number;
  reviews: number;
  tags: string[]; // e.g., ['Best Seller', 'New Arrival']
  skinType?: string;
  ingredients?: string[];
}

export interface CartItem extends Product {
  quantity: number;
}
