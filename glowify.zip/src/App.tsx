import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Search, Menu, X, Star, Heart, ArrowRight, Instagram, Twitter, Facebook, ShoppingCart, Trash2, Plus, Minus, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import { Product, CartItem } from './types';
import { PRODUCTS } from './constants';

// --- Components ---

const Navbar = ({ cartCount, onOpenCart }: { cartCount: number; onOpenCart: () => void }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-12 h-20 flex items-center justify-between",
      isScrolled ? "bg-brand-peach/80 backdrop-blur-md shadow-sm h-16" : "bg-transparent"
    )}>
      <div className="flex items-center gap-6">
        <Menu className="w-5 h-5 cursor-pointer lg:hidden" />
        <div className="hidden lg:flex items-center gap-10 text-[10px] font-bold tracking-[0.2em] uppercase border-b border-transparent">
          <Link to="/category/skincare" className="hover:text-brand-rose transition-colors">SKINCARE</Link>
          <Link to="/category/makeup" className="hover:text-brand-rose transition-colors">MAKEUP</Link>
          <Link to="/category/lip-care" className="hover:text-brand-rose transition-colors">LIP CARE</Link>
        </div>
      </div>

      <Link to="/" className="absolute left-1/2 -translate-x-1/2 text-2xl font-bold tracking-tighter text-brand-rose uppercase hover:opacity-80 transition-opacity">
        GLOWIFY
      </Link>

      <div className="flex items-center gap-5">
        <Search className="w-5 h-5 cursor-pointer hover:text-brand-rose transition-colors" />
        <div className="relative cursor-pointer" onClick={onOpenCart}>
          <ShoppingBag className="w-5 h-5 hover:text-brand-rose transition-colors" />
          {cartCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-brand-rose text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </div>
      </div>
    </nav>
  );
};

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product) => void;
  key?: string | number;
}

const ProductCard = ({ product, onAddToCart }: ProductCardProps) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group relative"
    >
      <div className="aspect-[3/4] overflow-hidden rounded-2xl bg-brand-beige relative">
        <Link to={`/product/${product.id}`}>
          <img 
            src={product.image} 
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            referrerPolicy="no-referrer"
          />
        </Link>
        <button 
          onClick={() => onAddToCart(product)}
          className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-sm text-brand-brown py-3 rounded-xl text-sm font-semibold opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 hover:bg-brand-rose hover:text-white"
        >
          Add to Cart
        </button>
        {product.tags.map((tag, i) => (
          <span key={i} className="absolute top-4 left-4 bg-brand-rose text-white text-[9px] px-2 py-1 rounded-full font-bold uppercase tracking-widest">
            {tag}
          </span>
        ))}
      </div>
      <div className="mt-3 flex justify-between items-start">
        <div className="space-y-1">
          <h4 className="text-xs font-bold uppercase tracking-tight">
            <Link to={`/product/${product.id}`} className="hover:text-brand-rose transition-colors">
              {product.name}
            </Link>
          </h4>
          <p className="text-[10px] text-brand-muted font-bold">${product.price.toFixed(2)}</p>
        </div>
        <button 
          onClick={() => onAddToCart(product)}
          className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center hover:bg-brand-rose hover:text-white hover:border-brand-rose transition-all"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
    </motion.div>
  );
};

const CartDrawer = ({ isOpen, onClose, cart, updateQuantity, removeFromCart }: {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  updateQuantity: (id: string, delta: number) => void;
  removeFromCart: (id: string) => void;
}) => {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]" 
          />
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-white z-[70] flex flex-col shadow-2xl"
          >
            <div className="p-6 border-bottom flex items-center justify-between">
              <h2 className="font-serif text-2xl font-bold">Your Bag ({cart.reduce((ac, cv) => ac + cv.quantity, 0)})</h2>
              <X className="w-6 h-6 cursor-pointer hover:rotate-90 transition-transform" onClick={onClose} />
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
                  <div className="w-20 h-20 bg-brand-pink rounded-full flex items-center justify-center">
                    <ShoppingBag className="w-10 h-10 text-brand-gold" />
                  </div>
                  <p className="text-gray-500">Your bag is empty.</p>
                  <button onClick={onClose} className="text-brand-gold font-bold hover:underline">Start Shopping</button>
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.id} className="flex gap-4 group">
                    <div className="w-24 h-32 flex-shrink-0 rounded-lg bg-brand-beige overflow-hidden">
                      <img src={item.image} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="flex-1 flex flex-col justify-between py-1">
                      <div>
                        <div className="flex justify-between items-start">
                          <h3 className="font-serif text-lg font-semibold leading-tight">{item.name}</h3>
                          <button onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="text-sm font-bold mt-1">${item.price.toFixed(2)}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1 border border-gray-200 rounded-lg p-1">
                          <button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:bg-gray-100 rounded">
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:bg-gray-100 rounded">
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
          <div className="p-6 bg-brand-beige space-y-4">
                <div className="flex justify-between items-end border-b border-brand-rose/10 pb-4">
                  <span className="text-brand-muted text-[10px] font-bold uppercase tracking-widest">Subtotal</span>
                  <span className="text-2xl font-light">${subtotal.toFixed(2)}</span>
                </div>
                <Link 
                  to="/checkout" 
                  onClick={onClose}
                  className="w-full bg-brand-rose text-white py-4 rounded-xl flex items-center justify-center gap-2 font-bold uppercase tracking-widest text-[10px] hover:bg-brand-brown transition-colors"
                >
                  Proceed to Checkout <ArrowRight className="w-4 h-4" />
                </Link>
                <Link 
                  to="/cart" 
                  onClick={onClose}
                  className="w-full text-center text-[10px] font-bold uppercase tracking-widest hover:text-brand-rose transition-colors"
                >
                  View Full Bag
                </Link>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

// --- Pages ---

const HomePage = ({ onAddToCart }: { onAddToCart: (p: Product) => void }) => {
  return (
    <div className="space-y-24 pb-24">
      {/* Hero Section */}
      <section className="relative h-screen flex px-12 pt-20">
        <div className="w-1/2 flex flex-col justify-center pr-12 z-10">
          <motion.div 
             initial={{ opacity: 0, x: -50 }}
             animate={{ opacity: 1, x: 0 }}
             transition={{ duration: 0.8, delay: 0.2 }}
             className="max-w-xl space-y-10"
          >
            <div>
              <span className="text-xs font-bold text-brand-rose uppercase tracking-[0.3em] mb-4 block">Artisanal Beauty</span>
              <h1 className="text-8xl font-light leading-[0.85] text-brand-brown -ml-1">
                Glow <br/> <span className="font-serif-italic text-7xl">Naturally.</span>
              </h1>
            </div>
            <p className="text-lg text-brand-muted leading-relaxed max-w-sm">
              Minimal formulas, premium ingredients. Designed for the generation that shines from within.
            </p>
            <div className="flex items-center space-x-6">
              <Link to="/category/skincare" className="px-10 py-5 bg-brand-rose text-white font-bold uppercase tracking-widest text-[10px] rounded-full shadow-xl shadow-rose-100 hover:scale-105 transition-transform flex items-center gap-2">
                Shop Glowify Now <ArrowRight className="w-4 h-4" />
              </Link>
              <button className="px-10 py-5 border border-brand-rose text-brand-rose font-bold uppercase tracking-widest text-[10px] rounded-full hover:bg-brand-rose hover:text-white transition-all">
                Our Story
              </button>
            </div>
          </motion.div>
        </div>
        
        <div className="w-1/2 relative flex items-center justify-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="relative w-[80%] aspect-[4/5] bg-brand-accent rounded-[180px] overflow-hidden shadow-2xl"
          >
             <img 
              src="https://images.unsplash.com/photo-1596462502278-27bfaf410411?auto=format&fit=crop&q=80&w=1200" 
              className="absolute inset-0 w-full h-full object-cover opacity-80"
              alt="Person glowing skin"
              referrerPolicy="no-referrer"
             />
             <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-[85%] h-[85%] border-4 border-white/40 rounded-[160px]"></div>
             </div>
             <div className="absolute bottom-10 left-10 text-white">
               <div className="text-4xl font-serif-italic">01</div>
               <div className="text-[10px] uppercase tracking-widest mt-2 font-bold">Radiant Serum</div>
             </div>
             <div className="absolute top-0 right-0 p-8">
                <div className="w-24 h-24 bg-brand-rose rounded-full flex items-center justify-center text-white text-[10px] font-bold uppercase text-center leading-tight rotate-12 shadow-lg">
                  New<br/>Arrival
                </div>
             </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className="absolute left-0 bottom-24 bg-white/80 backdrop-blur-md p-6 rounded-3xl shadow-lg z-20"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-brand-soft-pink rounded-full flex items-center justify-center">
                <Star className="w-5 h-5 text-brand-rose fill-brand-rose" />
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-widest font-bold">Best Seller ✨</div>
                <div className="text-xs text-brand-muted">Glass Skin Finisher</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Sticky Banner */}
      <div className="bg-brand-soft-pink py-4 overflow-hidden whitespace-nowrap border-y border-brand-rose/10">
        <motion.div 
          animate={{ x: [0, -1000] }}
          transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
          className="inline-block"
        >
          {[...Array(6)].map((_, i) => (
            <span key={i} className="inline-block text-[10px] font-bold uppercase tracking-[0.4em] text-brand-rose mx-8">
              Free Shipping Over $50 • Cruelty Free & Vegan • Dermatologist Approved • Limited Stock
            </span>
          ))}
        </motion.div>
      </div>

      {/* trending products */}
      <section className="container mx-auto px-12 space-y-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-brand-rose uppercase tracking-widest">Our Collections</span>
            <h2 className="text-5xl font-light leading-tight text-brand-brown">Trending <span className="font-serif-italic">Glow</span></h2>
          </div>
          <Link to="/category/all" className="text-[10px] uppercase tracking-widest font-bold text-brand-rose hover:underline underline-offset-8">
            View All Products
          </Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12">
          {PRODUCTS.slice(0, 4).map(product => (
            <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
          ))}
        </div>
      </section>

      {/* Newsletter - Artistic Style */}
      <section className="container mx-auto px-12">
        <div className="bg-white border-2 border-dashed border-brand-accent rounded-[3rem] p-16 lg:p-24 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <span className="text-[10px] font-bold text-brand-rose uppercase tracking-widest">Newsletter</span>
            <h2 className="text-5xl font-light leading-tight">Get <span className="font-serif-italic text-4xl">10% OFF</span> <br/> Your first order.</h2>
            <p className="text-brand-muted max-w-sm">Join our community and get early access to new drops and clean beauty tips.</p>
          </div>
          <form className="flex flex-col sm:flex-row gap-4" onSubmit={e => e.preventDefault()}>
            <input 
              type="email" 
              placeholder="Your email address" 
              className="flex-1 bg-brand-peach border-b-2 border-brand-rose px-0 py-4 outline-none focus:bg-white transition-all text-sm font-medium"
            />
            <button className="bg-brand-rose text-white px-10 py-4 rounded-full font-bold uppercase tracking-widest text-[10px] hover:bg-brand-brown transition-colors">Join Now</button>
          </form>
        </div>
      </section>
    </div>
  );
};

const ProductPage = ({ onAddToCart }: { onAddToCart: (p: Product) => void }) => {
  const { id } = useLocation().pathname.split('/').pop() ? { id: useLocation().pathname.split('/').pop() } : { id: '' };
  const product = PRODUCTS.find(p => p.id === id);
  const [qty, setQty] = useState(1);

  if (!product) return <div className="h-screen flex items-center justify-center font-serif text-3xl">Product not found</div>;

  return (
    <div className="container mx-auto px-6 pt-32 pb-24 space-y-24">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
        {/* Gallery */}
        <div className="space-y-4">
          <div className="aspect-[4/5] rounded-[2rem] overflow-hidden bg-brand-beige">
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="aspect-square rounded-2xl overflow-hidden bg-brand-beige border-2 border-transparent hover:border-brand-gold cursor-pointer transition-all">
                <img src={product.image} alt="" className={cn("w-full h-full object-cover", i > 0 && "opacity-50")} referrerPolicy="no-referrer" />
              </div>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="space-y-8 lg:sticky lg:top-32">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="bg-brand-soft-pink text-brand-rose text-[9px] font-bold px-2 py-1 rounded-full uppercase tracking-[0.2em]">{product.category}</span>
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 fill-brand-rose text-brand-rose" />
                <span className="text-xs font-bold text-brand-brown">{product.rating}</span>
                <span className="text-[10px] text-brand-muted uppercase font-bold">({product.reviews} reviews)</span>
              </div>
            </div>
            <h1 className="text-6xl lg:text-8xl font-light leading-tight text-brand-brown tracking-tighter">{product.name}</h1>
            <div className="flex items-center gap-4">
              <span className="text-3xl font-light">${product.price.toFixed(2)}</span>
              {product.oldPrice && <span className="text-xl text-brand-muted/40 line-through">${product.oldPrice.toFixed(2)}</span>}
            </div>
          </div>

          <p className="text-brand-muted leading-relaxed text-lg max-w-lg">{product.description}</p>

          <div className="space-y-4 border-y border-brand-rose/10 py-10">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] mb-3 text-brand-rose">Suitable For</p>
              <p className="font-serif-italic text-2xl text-brand-brown">{product.skinType}</p>
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] mb-3 text-brand-rose">Key Ingredients</p>
              <div className="flex flex-wrap gap-2">
                {product.ingredients?.map(ing => (
                  <span key={ing} className="bg-brand-beige px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-brand-brown border border-brand-brown/5">{ing}</span>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-5 border border-brand-rose/20 rounded-full px-6 py-4">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="hover:text-brand-rose transition-colors"><Minus className="w-4 h-4" /></button>
                <span className="w-12 text-center font-bold text-lg">{qty}</span>
                <button onClick={() => setQty(qty + 1)} className="hover:text-brand-rose transition-colors"><Plus className="w-4 h-4" /></button>
              </div>
              <button 
                onClick={() => onAddToCart(product)}
                className="flex-1 bg-brand-rose text-white py-5 rounded-full font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-2 hover:bg-brand-brown transition-all shadow-xl shadow-rose-100"
              >
                Add to Cart <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            <button className="w-full border border-brand-rose text-brand-rose py-5 rounded-full font-bold uppercase tracking-widest text-[10px] hover:bg-brand-rose hover:text-white transition-all">
              Direct Buy
            </button>
          </div>
          
          <div className="flex items-center justify-center gap-12 pt-4">
            <div className="text-center space-y-1">
              <div className="w-10 h-10 mx-auto rounded-full bg-brand-pink flex items-center justify-center">
                 <Check className="w-5 h-5 text-brand-gold" />
              </div>
              <p className="text-[10px] font-bold uppercase tracking-tighter">Vegan</p>
            </div>
            <div className="text-center space-y-1">
              <div className="w-10 h-10 mx-auto rounded-full bg-brand-pink flex items-center justify-center">
                 <Check className="w-5 h-5 text-brand-gold" />
              </div>
              <p className="text-[10px] font-bold uppercase tracking-tighter">No Silicones</p>
            </div>
            <div className="text-center space-y-1">
              <div className="w-10 h-10 mx-auto rounded-full bg-brand-pink flex items-center justify-center">
                 <Check className="w-5 h-5 text-brand-gold" />
              </div>
              <p className="text-[10px] font-bold uppercase tracking-tighter">Cruelty Free</p>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      <section className="space-y-12">
        <h2 className="text-5xl font-serif font-bold text-center">Complete Your Glow</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {PRODUCTS.slice(0, 4).map(p => (
            <ProductCard key={p.id} product={p} onAddToCart={onAddToCart} />
          ))}
        </div>
      </section>
    </div>
  );
};

const CategoryPage = ({ onAddToCart }: { onAddToCart: (p: Product) => void }) => {
  const category = useLocation().pathname.split('/').pop() || 'all';
  const filteredProducts = category === 'all' ? PRODUCTS : PRODUCTS.filter(p => p.category === category || category.includes(p.category));

  return (
    <div className="pt-40 pb-24 container mx-auto px-12 space-y-16">
      <div className="max-w-2xl space-y-4">
        <span className="text-[10px] font-bold text-brand-rose uppercase tracking-[0.3em]">Collection</span>
        <h1 className="text-7xl font-light tracking-tighter capitalize">{category.replace('-', ' ')} <span className="font-serif-italic">Essentials</span></h1>
        <p className="text-brand-muted max-w-sm">Artisanal formulas designed for peak skin health and natural radiance.</p>
      </div>
      
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12">
        {filteredProducts.map(product => (
          <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
        ))}
      </div>
    </div>
  );
};

const CheckoutPage = ({ cart, clearCart }: { cart: CartItem[]; clearCart: () => void }) => {
  const [success, setSuccess] = useState(false);
  const total = cart.reduce((ac, cv) => ac + cv.price * cv.quantity, 0);

  if (success) {
    return (
      <div className="h-screen pt-32 flex items-center justify-center bg-brand-peach">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white p-12 rounded-[3rem] text-center space-y-8 shadow-2xl max-w-lg mx-auto"
        >
          <div className="w-20 h-20 bg-brand-rose rounded-full flex items-center justify-center mx-auto shadow-xl shadow-rose-100">
            <Check className="w-10 h-10 text-white" />
          </div>
          <div className="space-y-4">
            <h2 className="text-4xl font-light leading-tight">Order <span className="font-serif-italic">Placed!</span></h2>
            <p className="text-brand-muted text-sm px-6">Thank you for choosing Glowify. Your skin will thank you soon. We've sent a confirmation email to you.</p>
          </div>
          <Link to="/" className="inline-block bg-brand-rose text-white px-10 py-4 rounded-full font-bold uppercase tracking-widest text-[10px] hover:bg-brand-brown transition-colors">Return to Shop</Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-40 pb-24 bg-brand-beige min-h-screen">
      <div className="container mx-auto px-12 grid grid-cols-1 lg:grid-cols-10 gap-16">
        <div className="lg:col-span-6 space-y-12">
           <div className="bg-white p-10 rounded-[2rem] shadow-sm space-y-8">
             <h2 className="text-3xl font-light">Shipping <span className="font-serif-italic">Details</span></h2>
             <form className="grid grid-cols-1 md:grid-cols-2 gap-6" onSubmit={(e) => { e.preventDefault(); setSuccess(true); clearCart(); }}>
                <input required placeholder="First Name" className="w-full bg-brand-peach border border-transparent rounded-xl px-6 py-4 outline-none focus:border-brand-rose transition-colors text-sm font-medium" />
                <input required placeholder="Last Name" className="w-full bg-brand-peach border border-transparent rounded-xl px-6 py-4 outline-none focus:border-brand-rose transition-colors text-sm font-medium" />
                <input required placeholder="Email Address" type="email" className="md:col-span-2 w-full bg-brand-peach border border-transparent rounded-xl px-6 py-4 outline-none focus:border-brand-rose transition-colors text-sm font-medium" />
                <input required placeholder="Full Address" className="md:col-span-2 w-full bg-brand-peach border border-transparent rounded-xl px-6 py-4 outline-none focus:border-brand-rose transition-colors text-sm font-medium" />
                <input required placeholder="City" className="w-full bg-brand-peach border border-transparent rounded-xl px-6 py-4 outline-none focus:border-brand-rose transition-colors text-sm font-medium" />
                <input required placeholder="Phone Number" className="w-full bg-brand-peach border border-transparent rounded-xl px-6 py-4 outline-none focus:border-brand-rose transition-colors text-sm font-medium" />
                
                <div className="md:col-span-2 space-y-4 pt-4">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-brand-rose">Payment Method</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="border-2 border-brand-rose bg-brand-soft-pink p-4 rounded-xl cursor-pointer">
                      <p className="text-[10px] font-bold uppercase tracking-widest text-brand-rose">Card Payment</p>
                    </div>
                    <div className="border border-brand-beige p-4 rounded-xl cursor-pointer hover:border-brand-rose transition-all">
                      <p className="text-[10px] font-bold uppercase tracking-widest text-brand-muted">Cash on Delivery</p>
                    </div>
                  </div>
                </div>

                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit" 
                  className="md:col-span-2 bg-brand-rose text-white py-6 rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-brand-brown transition-all shadow-xl shadow-rose-100 mt-8"
                >
                  Place My Order Now
                </motion.button>
             </form>
           </div>
        </div>
        
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-10 rounded-[2rem] shadow-sm space-y-8 lg:sticky lg:top-40">
            <h2 className="text-3xl font-light">Your <span className="font-serif-italic">Summary</span></h2>
            <div className="space-y-4 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
               {cart.map(item => (
                 <div key={item.id} className="flex gap-4 items-center">
                   <div className="w-16 h-16 rounded-lg overflow-hidden bg-brand-beige flex-shrink-0">
                     <img src={item.image} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                   </div>
                   <div className="flex-1">
                     <p className="font-bold text-xs uppercase tracking-tight leading-tight">{item.name}</p>
                     <p className="text-[10px] text-brand-muted uppercase font-bold mt-1">Qty: {item.quantity}</p>
                   </div>
                   <p className="font-bold text-xs text-brand-rose">${(item.price * item.quantity).toFixed(2)}</p>
                 </div>
               ))}
            </div>
            <div className="space-y-3 border-t border-brand-peach pt-8">
              <div className="flex justify-between text-brand-muted text-[10px] font-bold uppercase tracking-widest">
                <span>Subtotal</span>
                <span>${total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-brand-muted text-[10px] font-bold uppercase tracking-widest">
                <span>Shipping</span>
                <span className="text-brand-rose">Complementary</span>
              </div>
              <div className="flex justify-between text-brand-brown text-3xl font-light pt-4 border-t border-brand-peach">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Footer = () => (
  <footer className="bg-brand-peach pt-24 pb-12 border-t border-brand-rose/10">
    <div className="container mx-auto px-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-16">
      <div className="lg:col-span-2 space-y-8">
        <h2 className="text-3xl font-bold tracking-tighter text-brand-rose uppercase">GLOWIFY</h2>
        <p className="text-brand-muted max-w-sm leading-relaxed font-medium">Your daily dose of artisanal beauty. We believe in high-performance formulas that feel as good as they look.</p>
        <div className="flex gap-4 text-brand-rose">
           <Link to="#" className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:scale-110 transition-transform shadow-sm"><Instagram className="w-4 h-4" /></Link>
           <Link to="#" className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:scale-110 transition-transform shadow-sm"><Twitter className="w-4 h-4" /></Link>
           <Link to="#" className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:scale-110 transition-transform shadow-sm"><Facebook className="w-4 h-4" /></Link>
        </div>
      </div>
      <div className="space-y-6">
        <h4 className="font-bold uppercase tracking-[0.2em] text-[10px] text-brand-rose">Shop</h4>
        <ul className="space-y-4 text-xs font-bold uppercase tracking-widest text-brand-muted">
          <li><Link to="/category/skincare" className="hover:text-brand-rose transition-colors">Skincare</Link></li>
          <li><Link to="/category/makeup" className="hover:text-brand-rose transition-colors">Makeup</Link></li>
          <li><Link to="/category/lip-care" className="hover:text-brand-rose transition-colors">Lip Care</Link></li>
          <li><Link to="/category/all" className="hover:text-brand-rose transition-colors">New Arrivals</Link></li>
        </ul>
      </div>
      <div className="space-y-6">
        <h4 className="font-bold uppercase tracking-[0.2em] text-[10px] text-brand-rose">Brand</h4>
        <ul className="space-y-4 text-xs font-bold uppercase tracking-widest text-brand-muted">
          <li><Link to="#" className="hover:text-brand-rose transition-colors">Our Story</Link></li>
          <li><Link to="#" className="hover:text-brand-rose transition-colors">Ingredients</Link></li>
          <li><Link to="#" className="hover:text-brand-rose transition-colors">Sustainability</Link></li>
          <li><Link to="#" className="hover:text-brand-rose transition-colors">Reviews</Link></li>
        </ul>
      </div>
      <div className="space-y-6">
        <h4 className="font-bold uppercase tracking-[0.2em] text-[10px] text-brand-rose">Support</h4>
        <ul className="space-y-4 text-xs font-bold uppercase tracking-widest text-brand-muted">
          <li><Link to="#" className="hover:text-brand-rose transition-colors">Contact Us</Link></li>
          <li><Link to="#" className="hover:text-brand-rose transition-colors">Shipping Info</Link></li>
          <li><Link to="#" className="hover:text-brand-rose transition-colors">Returns</Link></li>
          <li><Link to="#" className="hover:text-brand-rose transition-colors">FAQ</Link></li>
        </ul>
      </div>
    </div>
    <div className="container mx-auto px-12 mt-24 pt-8 border-t border-brand-rose/5 flex flex-col md:flex-row justify-between items-center gap-6 text-[9px] uppercase tracking-[0.3em] font-bold text-brand-rose/40">
      <p>© 2026 GLOWIFY BEAUTY INC. ESTABLISHED IN RADIANCE.</p>
      <div className="flex gap-8">
        <Link to="#" className="hover:text-brand-rose">Privacy Policy</Link>
        <Link to="#" className="hover:text-brand-rose">Terms of Service</Link>
      </div>
    </div>
  </footer>
);

// --- App Entry ---

export default function App() {
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('glowify_cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('glowify_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const clearCart = () => setCart([]);

  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen selection:bg-brand-gold selection:text-white">
        <Banner />
        <Navbar cartCount={cart.reduce((ac, cv) => ac + cv.quantity, 0)} onOpenCart={() => setIsCartOpen(true)} />
        <CartDrawer 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)} 
          cart={cart}
          updateQuantity={updateQuantity}
          removeFromCart={removeFromCart}
        />
        
        <Routes>
          <Route path="/" element={<HomePage onAddToCart={addToCart} />} />
          <Route path="/product/:id" element={<ProductPage onAddToCart={addToCart} />} />
          <Route path="/category/:id" element={<CategoryPage onAddToCart={addToCart} />} />
          <Route path="/checkout" element={<CheckoutPage cart={cart} clearCart={clearCart} />} />
        </Routes>

        <Footer />
        <FloatingCTA />
      </div>
    </Router>
  );
}

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
};

const Banner = () => (
  <div className="bg-brand-rose text-white py-2 text-center text-[10px] font-bold uppercase tracking-[0.4em] relative z-[60]">
    Free shipping on all orders over $50 • Artisanal Beauty
  </div>
);

const FloatingCTA = () => {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const handle = () => setVisible(window.scrollY > 500);
    window.addEventListener('scroll', handle);
    return () => window.removeEventListener('scroll', handle);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div 
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-8 right-8 z-40 bg-black text-white px-6 py-4 rounded-full flex items-center space-x-4 shadow-2xl"
        >
          <div className="text-[10px] font-bold uppercase tracking-widest">Shop Now</div>
          <div className="h-4 w-px bg-white/20"></div>
          <Link to="/category/all" className="text-[10px] font-bold uppercase tracking-widest text-brand-rose hover:text-white transition-colors">
            Checkout Now →
          </Link>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
