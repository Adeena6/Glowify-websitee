import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Dewy Glass Serum',
    description: 'Achieve the ultimate glass skin look with our hydrating serum infused with hyaluronic acid and niacinamide.',
    price: 32.00,
    oldPrice: 40.00,
    category: 'skincare',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviews: 124,
    tags: ['Best Seller 🔥'],
    skinType: 'All Skin Types',
    ingredients: ['Hyaluronic Acid', 'Niacinamide', 'Glycerin', 'Panthenol']
  },
  {
    id: '2',
    name: 'Cloud Tint Lip Balm',
    description: 'A weightless, buildable lip tint that provides a soft-focus matte finish while keeping lips hydrated.',
    price: 22.00,
    category: 'lip-care',
    image: 'https://images.unsplash.com/photo-1586776977607-310e9c725c37?auto=format&fit=crop&q=80&w=800',
    rating: 4.7,
    reviews: 89,
    tags: ['Trending ✨'],
    skinType: 'Normal to Dry',
    ingredients: ['Shea Butter', 'Vitamin E', 'Jojoba Oil']
  },
  {
    id: '3',
    name: 'Velvet Matte Foundation',
    description: 'A breathable, full-coverage foundation with a natural velvet finish that lasts all day.',
    price: 38.00,
    oldPrice: 45.00,
    category: 'makeup',
    image: 'https://images.unsplash.com/photo-1599733594230-6b823276abcc?auto=format&fit=crop&q=80&w=800',
    rating: 4.5,
    reviews: 210,
    tags: ['Limited Stock ⚡'],
    skinType: 'Combination/Oily',
    ingredients: ['Squalane', 'Silica', 'Zinc Oxide']
  },
  {
    id: '4',
    name: 'Glow Mist Setting Spray',
    description: 'Ultra-fine mist that sets makeup with a luminous, dewy finish and refreshes skin instantly.',
    price: 28.00,
    category: 'face-care',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    reviews: 156,
    tags: ['Must Have ❤️'],
    skinType: 'All Skin Types',
    ingredients: ['Rose Water', 'Aloe Vera', 'Witch Hazel']
  },
  {
    id: '5',
    name: 'Radiance Eye Cream',
    description: 'Brighten and depuff with our caffeine-infused eye cream, perfect for early mornings.',
    price: 34.00,
    category: 'skincare',
    image: 'https://images.unsplash.com/photo-1594465919760-441fe5908ab0?auto=format&fit=crop&q=80&w=800',
    rating: 4.6,
    reviews: 95,
    tags: ['New'],
    skinType: 'Sensitive',
    ingredients: ['Caffeine', 'Peptides', 'Vitamin C']
  },
  {
    id: '6',
    name: 'Silk Blush Stick',
    description: 'Creamy, blendable blush that melts into the skin for a natural, flushed-from-within look.',
    price: 24.00,
    category: 'makeup',
    image: 'https://images.unsplash.com/photo-1522335789182-9ed88e34be62?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviews: 178,
    tags: ['Best Seller 🔥'],
    skinType: 'All Skin Types',
    ingredients: ['Candelilla Wax', 'Avocado Oil', 'Mineral Pigments']
  }
];
